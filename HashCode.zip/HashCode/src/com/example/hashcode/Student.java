package com.example.hashcode;

public class Student {
	
	String studentId;
	String email;
	String name;
	
	public Student(String studentId, String email, String name) {
		this.studentId = studentId;
		this.email = email;
		this.name = name;
	}
	
	// Hashcode present in Object class. So we have to override.
	@Override
	public int hashCode() {
		return studentId.hashCode();
	}
	
	public static void main(String[] args) {
		//different hascode. Because content is different
		Student student = new Student("1","amod@gmail.com","Amod");
		Student student1 = new Student("2","Alex@gmail.com","Alex");
		System.out.println(student.hashCode());
		System.out.println(student1.hashCode());
		
		// same hashcode becuase datatype and content both is same..
		Student student2 = new Student("3","amod@gmail.com","Amod");
		Student student3 = new Student("3","amod@gmail.com","Amod");
		System.out.println(student2.hashCode());
		System.out.println(student3.hashCode());
	}

}

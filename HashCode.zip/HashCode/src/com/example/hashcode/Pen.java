package com.example.hashcode;

public class Pen {
	public static void main(String[] args) {
		Pen pen = new Pen();
		System.out.println(pen);
		int hc = pen.hashCode();
		System.out.println(pen + " = " + hc);
		System.out.printf("%x", hc);
	}

}

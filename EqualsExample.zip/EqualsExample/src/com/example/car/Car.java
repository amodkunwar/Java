package com.example.car;

public class Car {

	String carModel;
	String carColour;
	Integer carNumber;

	public Car(String carModel, String carColour, Integer carNumber) {
		this.carModel = carModel;
		this.carColour = carColour;
		this.carNumber = carNumber;
	}

	// equals() present in object class. So we need to override. And it's return
	// type is Boolean

	@Override
	public boolean equals(Object obj) {
		boolean isSame = false;
		if (obj instanceof Car) {
			Car temp = (Car) obj;
			if (this.carNumber == temp.carNumber) {
				isSame = true;
			}
		}
		return isSame;
	}

	public static void main(String[] args) {
		// false
		Car car1 = new Car("A4", "Red", 123);
		Car car2 = new Car("B4", "Black", 124);
		System.out.println(car1.equals(car2));
		// true
		Car car3 = new Car("A4", "Red", 123);
		Car car4 = new Car("B4", "Black", 123);
		System.out.println(car3.equals(car4));

	}

}
